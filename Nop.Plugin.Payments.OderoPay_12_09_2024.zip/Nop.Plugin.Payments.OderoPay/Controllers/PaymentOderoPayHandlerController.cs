﻿using System.Security.Cryptography;
using Microsoft.AspNetCore.Mvc;
using Nop.Services.Orders;
using Nop.Core.Domain.Orders;
using Nop.Core.Events;
using TokenPay;
using TokenPay.Model;
using TokenPay.Request;
using Nop.Plugin.Payments.OderoPay.Models;
using TokenPay.Request.Common;
using System.Text;

namespace Nop.Plugin.Payments.OderoPay.Controllers
{
    public class PaymentOderoPayHandlerController : Controller
    {
        private readonly IOrderService _orderService;
        private readonly OderoPayPaymentSettings _oderoPayPaymentSettings;
        private readonly IEventPublisher _eventPublisher;

        public PaymentOderoPayHandlerController(IOrderService orderService, OderoPayPaymentSettings oderoPayPaymentSettings, IEventPublisher eventPublisher)
        {
            _orderService = orderService;
            _oderoPayPaymentSettings = oderoPayPaymentSettings;
            _eventPublisher = eventPublisher;
        }

        [HttpPost]
        public async Task<IActionResult> Handler([FromForm] Secure3DHandler model)
        {
            if (ModelState.IsValid)
            {
                var hashPrefix = "35J0ctmZph5n - m_a8OqmXxJMwqqFFfyZ";
                if (_oderoPayPaymentSettings.EndpointUrl.Contains("sand"))
                    hashPrefix = "ouc(]oCHiMgHZqOVJ2Zrel.Fbk]tPjIY"; //test ve canlı ortamda farklı


                var x = GenerateHashString(model, hashPrefix);

                var hash = ComputeSha256Hash($"{x}");

                if (hash != model.Hash)
                    return RedirectToAction("Index", "Home", new { area = "" });

                var order = _orderService.GetOrderByGuidAsync(new Guid(model.ConversationId)).Result;
                if (order == null || model.PaymentId == string.Empty)
                    return RedirectToAction("Index", "Home", new { area = "" });
                var client = new TokenPayClient(_oderoPayPaymentSettings.ApiKey, _oderoPayPaymentSettings.SecretKey, "https://sandbox-api-gateway.oderopay.com.tr");

                var check = client.Payment().Complete3DSPayment(new CompleteThreeDSPaymentRequest()
                    { PaymentId = Convert.ToInt64(model.PaymentId) });
                order.AuthorizationTransactionId = model.ConversationId;

                if (check.PaymentStatus == PaymentStatus.Success)
                {
                    
                    order.OrderStatus = OrderStatus.Processing;
                    order.PaymentStatus = Core.Domain.Payments.PaymentStatus.Paid;
                    
                    order.AuthorizationTransactionResult = check.CardUserKey;

                    order.CaptureTransactionId = model.PaymentId;
                    order.CaptureTransactionResult = "";
                    await _orderService.UpdateOrderAsync(order);


                    await _eventPublisher.PublishAsync(new OrderPlacedEvent(order));
                    return RedirectToRoute("CheckoutCompleted", new { orderId = order.Id });
                }

                
                order.OrderStatus = OrderStatus.Cancelled;
                order.PaymentStatus = Core.Domain.Payments.PaymentStatus.Voided;
                await _orderService.UpdateOrderAsync(order);
                //await _eventPublisher.PublishAsync(new OrderPlacedEvent(order));
            }

            return RedirectToAction("Index", "Home", new { area = "" });
        }
        [NonAction]
        private static string GenerateHashString(Secure3DHandler response, string hashPrefix)
        {
            var parts = new[]
            {
                hashPrefix,
                response.Status.ToString(),//// “SUCCESS” veya “FAILURE”
                response.PaymentId.ToString(),
                response.ConversationData ?? string.Empty,
                response.ConversationId ?? string.Empty,
                response.MdStatus?.ToString() ?? string.Empty
            };

            const string HashDelimiter = "###";
            var hashString = string.Join(HashDelimiter, parts);
            return hashString;
        }
        [NonAction]
        private static string ComputeSha256Hash(string rawData)
        {
            using var sha256 = SHA256.Create();
            var bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(rawData));
            var builder = new StringBuilder();
            foreach (var b in bytes)
            {
                builder.Append(b.ToString("x2"));
            }
            return builder.ToString();
        }



        [NonAction]
        private bool ProcessThePayment(Order order, Secure3DHandler model)
        {
            return false;
        }
    }
}
