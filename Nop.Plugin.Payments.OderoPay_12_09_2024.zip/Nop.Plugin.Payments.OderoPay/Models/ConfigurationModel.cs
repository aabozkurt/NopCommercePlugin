﻿using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc.ModelBinding;

namespace Nop.Plugin.Payments.OderoPay.Models
{
    public record ConfigurationModel : BaseNopModel
    {
        [NopResourceDisplayName("Plugins.Payments.OderoPay.Fields.ApiKey")]
        public string ApiKey { get; set; }
        public bool ApiKey_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugins.Payments.OderoPay.Fields.SecretKey")]
        public string SecretKey { get; set; }
        public bool SecretKey_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugins.Payments.OderoPay.Fields.EndpointUrl")]
        public string EndpointUrl { get; set; }
        public bool EndpointUrl_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugins.Payments.OderoPay.Fields.Use3DSecure")]
        public bool Use3DSecure { get; set; }
        public bool Use3DSecure_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugins.Payments.OderoPay.AdditionalFee")]
        public decimal AdditionalFee { get; set; }
        public bool AdditionalFee_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugins.Payments.OderoPay.AdditionalFeePercentage")]
        public bool AdditionalFeePercentage { get; set; }
        public bool AdditionalFeePercentage_OverrideForStore { get; set; }

        public int ActiveStoreScopeConfiguration { get; set; }
    }
}