﻿using System.ComponentModel.DataAnnotations;

namespace Nop.Plugin.Payments.OderoPay.Models
{
    public class Secure3DHandler
    {
        [Required]
        public string Status { get; set; }
        public string PaymentId { get; set; }
        public string ConversationId { get; set; }
        public string ConversationData { get; set; }

        public string MdStatus { get; set; }
        public string Hash { get; set; }

    }
}
