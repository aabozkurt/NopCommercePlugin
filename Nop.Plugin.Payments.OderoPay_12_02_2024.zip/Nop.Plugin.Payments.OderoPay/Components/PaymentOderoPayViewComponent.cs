﻿using System.Net;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Nop.Core;
using Nop.Plugin.Payments.OderoPay.Models;
using Nop.Services.Customers;
using Nop.Services.Orders;
using Nop.Services.Catalog;
using Nop.Services.Common;
using Nop.Services.Tax;
using Nop.Web.Framework.Components;
using Nop.Services.Directory;
using Nop.Services.Localization;
using TokenPay.Request;
using TokenPay;
using Nop.Services.Plugins;

namespace Nop.Plugin.Payments.OderoPay.Components
{
    public class PaymentOderoPayViewComponent : NopViewComponent
    {
        private readonly OderoPayPaymentSettings _oderoPayPaymentSettings;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ICustomerService _customerService;
        private readonly IShoppingCartService _shoppingCartService;
        private readonly IWorkContext _workContext;
        private readonly IProductService _productService;
        private readonly ITaxService _taxService;
        private readonly ICurrencyService _currencyService;
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly IOrderService _orderService;
        private readonly IStoreContext _storeContext;
        private readonly ILocalizationService _localizationService;

        public PaymentOderoPayViewComponent(OderoPayPaymentSettings oderoPayPaymentSettings, IHttpContextAccessor httpContextAccessor, ICustomerService customerService, IShoppingCartService shoppingCartService, IWorkContext workContext, IProductService productService, ITaxService taxService, ICurrencyService currencyService, IGenericAttributeService genericAttributeService, IOrderService orderService, IStoreContext storeContext, ILocalizationService localizationService)
        {
            _oderoPayPaymentSettings = oderoPayPaymentSettings;
            _httpContextAccessor = httpContextAccessor;
            _customerService = customerService;
            _shoppingCartService = shoppingCartService;
            _workContext = workContext;
            _productService = productService;
            _taxService = taxService;
            _currencyService = currencyService;
            _genericAttributeService = genericAttributeService;
            _orderService = orderService;
            _storeContext = storeContext;
            _localizationService = localizationService;
        }

        public async Task<IViewComponentResult> InvokeAsync()
        {
            var customer = await _workContext.GetCurrentCustomerAsync();
            var store = await _storeContext.GetCurrentStoreAsync();
            var model = new PaymentInfoModel() { StoredCards = new List<SelectListItem>() };
            var client = new TokenPayClient(_oderoPayPaymentSettings.ApiKey, _oderoPayPaymentSettings.SecretKey,
                _oderoPayPaymentSettings.EndpointUrl);
            var orders = await _orderService.SearchOrdersAsync(
                storeId: store.Id, customerId: customer.Id, paymentMethodSystemName: "Payments.OderoPay");
            foreach (var order in orders)
            {
                // may require if payment cancelled 
                // string.IsNullOrEmpty(order.AuthorizationTransactionCode) ||
                if (string.IsNullOrEmpty(order.AuthorizationTransactionResult))
                    continue;

                // Confirmed by the tokenpay team: no problem with exposing customer carduserkey data in this case.
                // In case of any issues, we can change this data to use the orderId instead.
                var cardUserKey = order.AuthorizationTransactionResult;

                var request = new SearchStoredCardsRequest { CardUserKey = cardUserKey };

                var response = client.Payment().SearchStoredCards(request);

                if (response == null || response.Items.Count != 1)
                    continue;

                var card = response.Items.First();

                var item = new SelectListItem()
                {
                    Text = $"{card.CardAlias}(**{card.LastFourDigits})-{card.CardBrand}",
                    Value = $"{cardUserKey}"
                };
                model.StoredCards.Add(item);
            }
            if (model.StoredCards.Count > 0)
                model.StoredCards.Insert(0, new SelectListItem()
                {
                    Text = $"{await _localizationService.GetResourceAsync("Plugins.Payments.OderoPay.Fields.SelectStoredCard")}",
                    Value = "Select"
                });


            // years
            for (var i = 0; i < 15; i++)
            {
                var year = (DateTime.Now.Year + i).ToString();
                model.ExpireYears.Add(new SelectListItem { Text = year, Value = year });
            }

            // months
            for (var i = 1; i <= 12; i++)
            {
                model.ExpireMonths.Add(new SelectListItem { Text = i.ToString("D2"), Value = i.ToString() });
            }

            // set postback values (we cannot access "Form" with "GET" requests)
            if (Request.Method != WebRequestMethods.Http.Get)
            {
                var form = Request.Form;
                model.CardholderName = form["CardholderName"];
                model.CardNumber = form["CardNumber"];
                model.CardCode = form["CardCode"];
                var selectedCcType = model.CreditCardTypes.FirstOrDefault(x => x.Value.Equals(form["CreditCardType"], StringComparison.InvariantCultureIgnoreCase));
                if (selectedCcType != null)
                    selectedCcType.Selected = true;
                var selectedMonth = model.ExpireMonths.FirstOrDefault(x => x.Value.Equals(form["ExpireMonth"], StringComparison.InvariantCultureIgnoreCase));
                if (selectedMonth != null)
                    selectedMonth.Selected = true;
                var selectedYear = model.ExpireYears.FirstOrDefault(x => x.Value.Equals(form["ExpireYear"], StringComparison.InvariantCultureIgnoreCase));
                if (selectedYear != null)
                    selectedYear.Selected = true;

            }

            return View("~/Plugins/Payments.OderoPay/Views/PaymentInfo.cshtml", model);
        }
    }
}
