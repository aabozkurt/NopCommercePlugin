﻿using Nop.Services.Localization;
using FluentValidation;
using Nop.Plugin.Payments.OderoPay.Models;
using Nop.Web.Framework.Validators;

namespace Nop.Plugin.Payments.OderoPay.PaymentInfoValidator
{
    public class PaymentInfoValidator : BaseNopValidator<PaymentInfoModel>
    {
        #region Ctor

        private readonly ILocalizationService _localizationService;
        public PaymentInfoValidator(ILocalizationService localizationService)
        {
            _localizationService = localizationService;
            RuleFor(x => x.CardholderName).NotEmpty().WithMessage(_localizationService.GetResourceAsync("Payment.CardholderName.Required").Result);
            RuleFor(x => x.CardNumber).NotEmpty().WithMessage(_localizationService.GetResourceAsync("Payment.CardNumber.Required").Result);
            RuleFor(x => x.CardNumber).CreditCard().WithMessage(_localizationService.GetResourceAsync("Payment.CardNumber.Wrong").Result);
            RuleFor(x => x.CardCode).Matches(@"^[0-9]{3,4}$").WithMessage(_localizationService.GetResourceAsync("Payment.CardCode.Wrong").Result);
            RuleFor(x => x.ExpireMonth).NotEmpty().WithMessage(_localizationService.GetResourceAsync("Payment.ExpireMonth.Required").Result);
            RuleFor(x => x.ExpireYear).NotEmpty().WithMessage(_localizationService.GetResourceAsync("Payment.ExpireYear.Required").Result);
            //RuleFor(x => x.AllowStoreCard).NotEmpty();
            //RuleFor(x => x.CardAlias).Length(3, 20);
        }

        #endregion
    }
}

