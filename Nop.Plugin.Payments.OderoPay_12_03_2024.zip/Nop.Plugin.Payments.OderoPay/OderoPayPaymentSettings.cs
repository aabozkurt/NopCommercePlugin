﻿using Nop.Core.Configuration;

namespace Nop.Plugin.Payments.OderoPay
{
    public class OderoPayPaymentSettings : ISettings
    {
        public string ApiKey { get; set; }
        public string SecretKey { get; set; }
        public string EndpointUrl { get; set; }
        public bool Use3DSecure { get; set; }
        public bool AdditionalFeePercentage { get; set; }
        public decimal AdditionalFee { get; set; }
    }
}