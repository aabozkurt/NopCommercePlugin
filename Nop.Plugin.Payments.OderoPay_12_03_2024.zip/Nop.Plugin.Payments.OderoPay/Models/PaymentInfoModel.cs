﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;
using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc.ModelBinding;

namespace Nop.Plugin.Payments.OderoPay.Models;

public record PaymentInfoModel : BaseNopModel
{
    public PaymentInfoModel()
    {
        CreditCardTypes = new List<SelectListItem>();
        ExpireMonths = new List<SelectListItem>();
        ExpireYears = new List<SelectListItem>();
        StoredCards = new List<SelectListItem>();
    }
    [Required(ErrorMessage = "Kayıtlı Kredi Kartı.")]
    [NopResourceDisplayName("Payment.StoredCard")]
    public string StoredCard { get; set; }

    public IList<SelectListItem> StoredCards { get; set; }

    [Required(ErrorMessage = "Lütfen bir kredi kartı türü seçin.")]
    [NopResourceDisplayName("Payment.SelectCreditCard")]
    public string CreditCardType { get; set; }

    [NopResourceDisplayName("Payment.SelectCreditCard")]
    public IList<SelectListItem> CreditCardTypes { get; set; }

    [Required(ErrorMessage = "Kart sahibi adı gereklidir.")]
    [NopResourceDisplayName("Payment.CardholderName")]
    public string CardholderName { get; set; }

    [Required(ErrorMessage = "Kart numarası gereklidir.")]
    [CreditCard(ErrorMessage = "Lütfen geçerli bir kredi kartı numarası girin.")]
    [NopResourceDisplayName("Payment.CardNumber")]
    public string CardNumber { get; set; }

    [Required(ErrorMessage = "Son kullanma ayı gereklidir.")]
    [NopResourceDisplayName("Payment.ExpirationDate")]
    public string ExpireMonth { get; set; }

    [Required(ErrorMessage = "Son kullanma yılı gereklidir.")]
    [NopResourceDisplayName("Payment.ExpirationDate")]
    public string ExpireYear { get; set; }

    public IList<SelectListItem> ExpireMonths { get; set; }

    public IList<SelectListItem> ExpireYears { get; set; }

    [Required(ErrorMessage = "Güvenlik kodu (CVC) gereklidir.")]
    [StringLength(4, ErrorMessage = "Güvenlik kodu (CVC) 4 karakterden fazla olamaz.")]
    [NopResourceDisplayName("Payment.CardCode")]
    public string CardCode { get; set; }

    [NopResourceDisplayName("Payment.AllowStoreCard")]
    public bool AllowStoreCard { get; set; }

    [StringLength(20, ErrorMessage = "Kayıt edilecek kart ismi 20 karakterden uzun olamaz.")]
    [NopResourceDisplayName("Payment.CardCode")]
    public string CardAlias { get; set; }

    [NopResourceDisplayName("Payment.Use3dSecure")]
    public string Use3dSecure { get; set; }
}