﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Core.Domain.Orders;
using Nop.Plugin.Payments.OderoPay.Models;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Messages;
using Nop.Services.Orders;
using Nop.Services.Security;
using Nop.Web.Framework;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Mvc.Filters;

namespace Nop.Plugin.Payments.OderoPay.Controllers
{
    [AuthorizeAdmin]
    [Area(AreaNames.ADMIN)]
    [AutoValidateAntiforgeryToken]
    public class PaymentOderoPayController : BasePluginController
    {
        private readonly ILocalizationService _localizationService;
        private readonly INotificationService _notificationService;
        private readonly IPermissionService _permissionService;
        private readonly ISettingService _settingService;
        private readonly IStoreContext _storeContext;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IOrderService _orderService;

        public PaymentOderoPayController(ILocalizationService localizationService,
            INotificationService notificationService,
            IPermissionService permissionService,
            ISettingService settingService,
            IStoreContext storeContext, IHttpContextAccessor httpContextAccessor, IOrderService orderService)
        {
            _localizationService = localizationService;
            _notificationService = notificationService;
            _permissionService = permissionService;
            _settingService = settingService;
            _storeContext = storeContext;
            _httpContextAccessor = httpContextAccessor;
            _orderService = orderService;
        }
        [HttpPost]
        public IActionResult Handler([FromForm] Secure3DHandler model)
        {
            if (ModelState.IsValid)
            {
                var order = _orderService.GetOrderByGuidAsync(new Guid(model.conversationId)).Result;
                if (order != null)
                {
                    var result = ProcessThePayment(order, model);

                    if (result)
                        return RedirectToRoute("CheckoutCompleted", new { orderId = order.Id });
                }
            }

            return RedirectToAction("Index", "Home", new { area = "" });
        }

        [NonAction]
        private bool ProcessThePayment(Order order, Secure3DHandler model)
        {
            return false;
        }
        public async Task<IActionResult> Configure()
        {
            if (!await _permissionService.AuthorizeAsync(StandardPermissionProvider.ManagePaymentMethods))
                return AccessDeniedView();

            var storeScope = await _storeContext.GetActiveStoreScopeConfigurationAsync();
            var oderoPayPaymentSettings = await _settingService.LoadSettingAsync<OderoPayPaymentSettings>(storeScope);

            var model = new ConfigurationModel
            {
                ApiKey = oderoPayPaymentSettings.ApiKey,
                SecretKey = oderoPayPaymentSettings.SecretKey,
                EndpointUrl = oderoPayPaymentSettings.EndpointUrl,
                Use3DSecure = oderoPayPaymentSettings.Use3DSecure,
                AdditionalFee = oderoPayPaymentSettings.AdditionalFee,
                AdditionalFeePercentage = oderoPayPaymentSettings.AdditionalFeePercentage,
                ActiveStoreScopeConfiguration = storeScope
            };

            if (storeScope > 0)
            {
                model.ApiKey_OverrideForStore = await _settingService.SettingExistsAsync(oderoPayPaymentSettings, x => x.ApiKey, storeScope);
                model.SecretKey_OverrideForStore = await _settingService.SettingExistsAsync(oderoPayPaymentSettings, x => x.SecretKey, storeScope);
                model.EndpointUrl_OverrideForStore = await _settingService.SettingExistsAsync(oderoPayPaymentSettings, x => x.EndpointUrl, storeScope);
                model.Use3DSecure_OverrideForStore = await _settingService.SettingExistsAsync(oderoPayPaymentSettings, x => x.Use3DSecure, storeScope);
                model.AdditionalFee_OverrideForStore = await _settingService.SettingExistsAsync(oderoPayPaymentSettings, x => x.AdditionalFee, storeScope);
                model.AdditionalFeePercentage_OverrideForStore = await _settingService.SettingExistsAsync(oderoPayPaymentSettings, x => x.AdditionalFeePercentage, storeScope);
            }

            return View("~/Plugins/Payments.OderoPay/Views/Configure.cshtml", model);
        }

        [HttpPost]
        public async Task<IActionResult> Configure(ConfigurationModel model)
        {
            if (!await _permissionService.AuthorizeAsync(StandardPermissionProvider.ManagePaymentMethods))
                return AccessDeniedView();

            if (!ModelState.IsValid)
                return await Configure();

            var storeScope = await _storeContext.GetActiveStoreScopeConfigurationAsync();
            var oderoPayPaymentSettings = await _settingService.LoadSettingAsync<OderoPayPaymentSettings>(storeScope);

            oderoPayPaymentSettings.ApiKey = model.ApiKey;
            oderoPayPaymentSettings.SecretKey = model.SecretKey;
            oderoPayPaymentSettings.EndpointUrl = model.EndpointUrl;
            oderoPayPaymentSettings.Use3DSecure = model.Use3DSecure;
            oderoPayPaymentSettings.AdditionalFee = model.AdditionalFee;
            oderoPayPaymentSettings.AdditionalFeePercentage = model.AdditionalFeePercentage;

            await _settingService.SaveSettingOverridablePerStoreAsync(oderoPayPaymentSettings, x => x.ApiKey, model.ApiKey_OverrideForStore, storeScope, false);
            await _settingService.SaveSettingOverridablePerStoreAsync(oderoPayPaymentSettings, x => x.SecretKey, model.SecretKey_OverrideForStore, storeScope, false);
            await _settingService.SaveSettingOverridablePerStoreAsync(oderoPayPaymentSettings, x => x.EndpointUrl, model.EndpointUrl_OverrideForStore, storeScope, false);
            await _settingService.SaveSettingOverridablePerStoreAsync(oderoPayPaymentSettings, x => x.Use3DSecure, model.Use3DSecure_OverrideForStore, storeScope, false);
            await _settingService.SaveSettingOverridablePerStoreAsync(oderoPayPaymentSettings, x => x.AdditionalFee, model.AdditionalFee_OverrideForStore, storeScope, false);
            await _settingService.SaveSettingOverridablePerStoreAsync(oderoPayPaymentSettings, x => x.AdditionalFeePercentage, model.AdditionalFeePercentage_OverrideForStore, storeScope, false);

            await _settingService.ClearCacheAsync();

            _notificationService.SuccessNotification(await _localizationService.GetResourceAsync("Admin.Plugins.Saved"));

            return await Configure();
        }
    }
}
