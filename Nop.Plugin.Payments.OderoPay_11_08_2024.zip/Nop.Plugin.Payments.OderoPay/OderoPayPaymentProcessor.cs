﻿using Azure.Core;
using Microsoft.AspNetCore.Http;
using Nop.Core;
using Nop.Core.Domain.Gdpr;
using Nop.Core.Domain.Orders;
using Nop.Plugin.Payments.OderoPay.Components;
using Nop.Plugin.Payments.OderoPay.Models;
using Nop.Services.Catalog;
using Nop.Services.Configuration;
using Nop.Services.Customers;
using Nop.Services.Directory;
using Nop.Services.Localization;
using Nop.Services.Orders;
using Nop.Services.Payments;
using Nop.Services.Plugins;
using Nop.Services.Tax;
using QuestPDF.Drawing;
using TokenPay;
using TokenPay.Model;
using TokenPay.Request;
using TokenPay.Request.Dto;
using PaymentStatus = Nop.Core.Domain.Payments.PaymentStatus;
using RefundPaymentRequest = Nop.Services.Payments.RefundPaymentRequest;

namespace Nop.Plugin.Payments.OderoPay
{
    public class OderoPayPaymentProcessor : BasePlugin, IPaymentMethod
    {
        private readonly ILocalizationService _localizationService;
        private readonly IOrderTotalCalculationService _orderTotalCalculationService;
        private readonly ISettingService _settingService;
        private readonly IWebHelper _webHelper;
        private readonly OderoPayPaymentSettings _oderoPayPaymentSettings;
        private readonly ICustomerService _customerService;
        private readonly IShoppingCartService _shoppingCartService;
        private readonly IProductService _productService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ITaxService _taxService;
        private readonly ICurrencyService _currencyService;
        private readonly IWorkContext _workContext;
        private readonly IOrderService _orderService;

        public OderoPayPaymentProcessor(ILocalizationService localizationService,
            IOrderTotalCalculationService orderTotalCalculationService,
            ISettingService settingService,
            IWebHelper webHelper,
            OderoPayPaymentSettings oderoPayPaymentSettings, ICustomerService customerService, IShoppingCartService shoppingCartService, IProductService productService, IHttpContextAccessor httpContextAccessor, ITaxService taxService, ICurrencyService currencyService, IWorkContext workContext, IOrderService orderService)
        {
            _localizationService = localizationService;
            _orderTotalCalculationService = orderTotalCalculationService;
            _settingService = settingService;
            _webHelper = webHelper;
            _oderoPayPaymentSettings = oderoPayPaymentSettings;
            _customerService = customerService;
            _shoppingCartService = shoppingCartService;
            _productService = productService;
            _httpContextAccessor = httpContextAccessor;
            _taxService = taxService;
            _currencyService = currencyService;
            _workContext = workContext;
            _orderService = orderService;
        }

        public Task<ProcessPaymentResult> ProcessPaymentAsync(ProcessPaymentRequest processPaymentRequest)
        {
            //var result = new ProcessPaymentResult
            //{
            //    AllowStoringCreditCardNumber = true
            //};
            //result.NewPaymentStatus = PaymentStatus.Pending;
            //return Task.FromResult(result);
            if (processPaymentRequest.CreditCardType == "3dSecurePayment")
            {
                var result = Process3DSecurePaymentAsync(processPaymentRequest);
                return result;
            }
            else
            {
                var result = ProcessCheckoutPaymentAsync(processPaymentRequest);
                return result;
            }

        }
        #region Sipariş kontrol

        private async Task<PaymentStatus> GetPaymentStatusAsync(PostProcessPaymentRequest postProcessPaymentRequest)
        {
            // Ödeme sağlayıcısından yanıt al ve durumu kontrol et
            // Bu örnekte, ödeme sağlayıcısının yanıtını simüle ediyoruz.
            var response = await SimulatePaymentProviderResponseAsync(postProcessPaymentRequest);

            // Yanıta göre ödeme durumunu döndür
            if (response.IsSuccess)
            {
                return PaymentStatus.Paid;
            }
            else
            {
                return PaymentStatus.Voided;
            }
        }

        private async Task HandleFailedPaymentAsync(PostProcessPaymentRequest postProcessPaymentRequest)
        {
            // İşlemi iptal etme işlemleri
            var order = await _orderService.GetOrderByIdAsync(postProcessPaymentRequest.Order.Id);
            if (order != null)
            {
                order.PaymentStatus = PaymentStatus.Voided;
                await _orderService.UpdateOrderAsync(order);
            }
        }

        private async Task HandleSuccessfulPaymentAsync(PostProcessPaymentRequest postProcessPaymentRequest)
        {
            // İşlemi tamamlama işlemleri
            var order = await _orderService.GetOrderByIdAsync(postProcessPaymentRequest.Order.Id);
            if (order != null)
            {
                order.PaymentStatus = PaymentStatus.Paid;
                await _orderService.UpdateOrderAsync(order);
            }
        }

        private async Task<PaymentProviderResponse> SimulatePaymentProviderResponseAsync(PostProcessPaymentRequest postProcessPaymentRequest)
        {
            // Bu örnekte, ödeme sağlayıcısından gelen yanıtı simüle ediyoruz
            await Task.Delay(100); // Ödeme sağlayıcısından yanıt bekleme süresi

            // Yanıtın başarılı olup olmadığını belirleyen simüle edilmiş yanıt
            return new PaymentProviderResponse { IsSuccess = false };
        }

        private class PaymentProviderResponse
        {
            public bool IsSuccess { get; set; }
        }


        #endregion
        public async Task PostProcessPaymentAsync(PostProcessPaymentRequest postProcessPaymentRequest)
        {


            // Ödeme sağlayıcısının yanıtını kontrol et






            var htmlContent = _httpContextAccessor.HttpContext?.Session.GetString("Odero.HtmlContent");
            var order = postProcessPaymentRequest.Order;

            order.CaptureTransactionResult = htmlContent;
            await _orderService.UpdateOrderAsync(order);
            if (!string.IsNullOrEmpty(htmlContent))
            {

                _httpContextAccessor.HttpContext.Response.Clear();


                _httpContextAccessor.HttpContext.Response.ContentType = "text/html";


                _httpContextAccessor.HttpContext.Response.WriteAsync(htmlContent);


                _httpContextAccessor.HttpContext.Response.CompleteAsync();
            }
            else
            {
               
                _ = HandleFailedPaymentAsync(postProcessPaymentRequest);
            }

            
        }


        private async Task<ProcessPaymentResult> Process3DSecurePaymentAsync(ProcessPaymentRequest processPaymentRequest)
        {
            var callBack = $"{_webHelper.GetStoreLocation()}Odero/Handler";
            var result = new ProcessPaymentResult();
            var client = new TokenPayClient(_oderoPayPaymentSettings.ApiKey, _oderoPayPaymentSettings.SecretKey, _oderoPayPaymentSettings.EndpointUrl);
            var customer = await _customerService.GetCustomerByIdAsync(processPaymentRequest.CustomerId);
             
            var request = new InitThreeDSPaymentRequest
            {
                Price = processPaymentRequest.OrderTotal,
                PaidPrice = processPaymentRequest.OrderTotal,
                WalletPrice = new decimal(0.0),
                Installment = 1,
                ConversationId = processPaymentRequest.OrderGuid.ToString(),
                Currency = Currency.Try,
                PaymentGroup = PaymentGroup.Product,
                CallbackUrl = callBack,
                Card = new Card(),
                Items = await GetItems(customer, processPaymentRequest.StoreId)
            };

            if (processPaymentRequest.CustomValues.TryGetValue("StoredCardUserKey", out var storedCardUserKey))
            {
                var searchStoredCardRequest = new SearchStoredCardsRequest() {CardUserKey = storedCardUserKey.ToString()};
                var searchStoredCardResponse = client.Payment().SearchStoredCards(searchStoredCardRequest);
                if (searchStoredCardResponse != null && searchStoredCardResponse.Items.Count == 1)
                {
                    var storedCard = searchStoredCardResponse.Items.First();
                    request.Card.CardUserKey = storedCard.CardUserKey;
                    request.Card.CardToken = storedCard.CardToken;
                }
            }
            else
            {
                request.Card.CardHolderName = processPaymentRequest.CreditCardName;
                request.Card.CardNumber = processPaymentRequest.CreditCardNumber;
                request.Card.ExpireYear = processPaymentRequest.CreditCardExpireYear.ToString();
                request.Card.ExpireMonth = processPaymentRequest.CreditCardExpireMonth.ToString().Length == 1
                    ? "0" + processPaymentRequest.CreditCardExpireMonth.ToString()
                    : processPaymentRequest.CreditCardExpireMonth.ToString();
                request.Card.Cvc = processPaymentRequest.CreditCardCvv2;
                if (processPaymentRequest.CustomValues.TryGetValue("AllowStoreCard", out var allowStoreCardValue)
                    && allowStoreCardValue is true)
                {
                    request.Card.StoreCardAfterSuccessPayment = true;
                    if (processPaymentRequest.CustomValues.TryGetValue("CardAlias", out var cardAliasValue))
                    {
                        request.Card.CardAlias = cardAliasValue.ToString();
                        result.AuthorizationTransactionCode = cardAliasValue.ToString();
                    }
                }
            }

            try
            {
                var response = client.Payment().Init3DSPayment(request);


                if (response is { HtmlContent: not null } && response.GetDecodedHtmlContent() != null)
                {
                    var html = response.GetDecodedHtmlContent();
                    
                    //TODO should be stored on customer attributes
                    _httpContextAccessor.HttpContext?.Session.SetString("Odero.HtmlContent", html);

                    result.NewPaymentStatus = PaymentStatus.Pending;

                    return await Task.FromResult(result);

                }

                result.AddError("3D Secure payment initiation failed.");
            }
            catch (Exception ex)
            {
                result.AddError(ex.Message);

            }
            return result;
        }

        private async Task<ProcessPaymentResult> ProcessCheckoutPaymentAsync(ProcessPaymentRequest processPaymentRequest)
        {
            var result = new ProcessPaymentResult();
            var client = new TokenPayClient(_oderoPayPaymentSettings.ApiKey, _oderoPayPaymentSettings.SecretKey, _oderoPayPaymentSettings.EndpointUrl);
            var customer = await _customerService.GetCustomerByIdAsync(processPaymentRequest.CustomerId);
 
            var request = new CreatePaymentRequest()
            {
                Price = processPaymentRequest.OrderTotal,
                PaidPrice = processPaymentRequest.OrderTotal,
                WalletPrice = new decimal(0.0),
                Installment = 1,
                ConversationId = processPaymentRequest.OrderGuid.ToString(),
                Currency = Currency.Try,
                PaymentGroup = PaymentGroup.Product,
                Card = new Card(),
                Items = await GetItems(customer, processPaymentRequest.StoreId)
            };
            if (processPaymentRequest.CustomValues.TryGetValue("StoredCardUserKey", out var storedCardUserKey))
            {
                var searchStoredCardRequest = new SearchStoredCardsRequest() { CardUserKey = storedCardUserKey.ToString() };
                var searchStoredCardResponse = client.Payment().SearchStoredCards(searchStoredCardRequest);
                if (searchStoredCardResponse != null && searchStoredCardResponse.Items.Count == 1)
                {
                    var storedCard = searchStoredCardResponse.Items.First();
                    request.Card.CardUserKey = storedCard.CardUserKey;
                    request.Card.CardToken = storedCard.CardToken;
                }
            }
            else
            {
                request.Card.CardHolderName = processPaymentRequest.CreditCardName;
                request.Card.CardNumber = processPaymentRequest.CreditCardNumber;
                request.Card.ExpireYear = processPaymentRequest.CreditCardExpireYear.ToString();
                request.Card.ExpireMonth = processPaymentRequest.CreditCardExpireMonth.ToString().Length == 1
                    ? "0" + processPaymentRequest.CreditCardExpireMonth.ToString()
                    : processPaymentRequest.CreditCardExpireMonth.ToString();
                request.Card.Cvc = processPaymentRequest.CreditCardCvv2;
                if (processPaymentRequest.CustomValues.TryGetValue("AllowStoreCard", out var allowStoreCardValue)
                    && allowStoreCardValue is true)
                {
                    request.Card.StoreCardAfterSuccessPayment = true;
                    if (processPaymentRequest.CustomValues.TryGetValue("CardAlias", out var cardAliasValue))
                    {
                        request.Card.CardAlias = cardAliasValue.ToString();
                        result.AuthorizationTransactionCode = cardAliasValue.ToString();
                    }
                }
            }
            try
            {
                var response = client.Payment().CreatePayment(request);


                if (response is {PaymentStatus:TokenPay.Model.PaymentStatus.Success})
                {

                    result.AuthorizationTransactionId = response.ConversationId;
                    result.NewPaymentStatus = PaymentStatus.Paid;
                    if (request.Card.StoreCardAfterSuccessPayment == true)
                        result.AuthorizationTransactionResult = response.CardUserKey;

                    return await Task.FromResult(result);

                }

                result.AddError("Payment failed.");
            }
            catch (NopException ex)
            {
                result.AddError(ex.Message);
            }
            return result;
        }
        private async Task<List<PaymentItem>> GetItems(Core.Domain.Customers.Customer customer, int storeId)
        {
            var items = new List<PaymentItem>();

            //get current shopping cart            
            var shoppingCart = await _shoppingCartService.GetShoppingCartAsync(customer, ShoppingCartType.ShoppingCart, storeId);

            //define function to create item
            Task<PaymentItem> createItem(decimal price, string productId, string productName)
            {
                return Task.FromResult(new PaymentItem
                {

                    Name = productName,
                    ExternalId = productId,
                    Price = price
                });
            }


            foreach (var cartItem in shoppingCart)
            {
                var product = _productService.GetProductByIdAsync(cartItem.ProductId).Result;
                var unitPrice = _shoppingCartService.GetUnitPriceAsync(cartItem, true).Result;
                var shoppingCartUnitPriceWithDiscountBase = _taxService.GetProductPriceAsync(product, unitPrice.unitPrice, customer).Result;
                var shoppingCartUnitPriceWithDiscount = _currencyService.ConvertFromPrimaryStoreCurrencyAsync(shoppingCartUnitPriceWithDiscountBase.price, _workContext.GetWorkingCurrencyAsync().Result).Result;

                items.Add(new PaymentItem()
                {
                    Price = shoppingCartUnitPriceWithDiscount * cartItem.Quantity,
                    ExternalId = product.Id.ToString(),
                    Name = product.Name
                });
            }


            //shipping without tax
            var shoppingCartShipping = _orderTotalCalculationService.GetShoppingCartShippingTotalAsync(shoppingCart, false).Result;
            if (shoppingCartShipping.shippingTotal > 0)
            {
                items.Add(createItem(shoppingCartShipping.shippingTotal ?? 0,
                    Guid.NewGuid().ToString(),
                    "Shipping").Result);
            }

            return items;
        }


        public Task<bool> HidePaymentMethodAsync(IList<ShoppingCartItem> cart)
        {
            return Task.FromResult(false);
        }

        public async Task<decimal> GetAdditionalHandlingFeeAsync(IList<ShoppingCartItem> cart)
        {
            return await _orderTotalCalculationService.CalculatePaymentAdditionalFeeAsync(cart,
                _oderoPayPaymentSettings.AdditionalFee, _oderoPayPaymentSettings.AdditionalFeePercentage);
        }

        public Task<CapturePaymentResult> CaptureAsync(CapturePaymentRequest capturePaymentRequest)
        {
            return Task.FromResult(new CapturePaymentResult { Errors = new[] { "Capture method not supported" } });
        }

        public async Task<RefundPaymentResult> RefundAsync(RefundPaymentRequest refundPaymentRequest)
        {
            var order = refundPaymentRequest.Order;
            var result = new RefundPaymentResult();
            if (!long.TryParse(order.AuthorizationTransactionId, out var paymentId))
                throw new NopException("AuthorizationTransaction id is null or not long.");

            var client = new TokenPayClient(_oderoPayPaymentSettings.ApiKey, _oderoPayPaymentSettings.SecretKey, _oderoPayPaymentSettings.EndpointUrl);

            var request = new TokenPay.Request.RefundPaymentRequest()
            {
                ConversationId = order.OrderGuid.ToString(), PaymentId = paymentId
            };

            var response = client.Payment().RefundPayment(request);
            if (response.Status == RefundStatus.Success)
            {
                result.NewPaymentStatus = PaymentStatus.Refunded;
                return result;
            }

            result.AddError(response.Status.ToString());
            return result;
            ;
        }
        
        public Task<VoidPaymentResult> VoidAsync(VoidPaymentRequest voidPaymentRequest)
        {
            return Task.FromResult(new VoidPaymentResult { Errors = new[] { "Void method not supported" } });
        }

        public Task<ProcessPaymentResult> ProcessRecurringPaymentAsync(ProcessPaymentRequest processPaymentRequest)
        {
            var result = new ProcessPaymentResult
            {
                AllowStoringCreditCardNumber = true
            };
            result.NewPaymentStatus = PaymentStatus.Pending;
            return Task.FromResult(result);
        }

        public Task<CancelRecurringPaymentResult> CancelRecurringPaymentAsync(CancelRecurringPaymentRequest cancelPaymentRequest)
        {
            return Task.FromResult(new CancelRecurringPaymentResult());
        }

        public Task<bool> CanRePostProcessPaymentAsync(Order order)
        {
            return Task.FromResult(false);
        }

        public Task<IList<string>> ValidatePaymentFormAsync(IFormCollection form)
        {
            var warnings = new List<string>();
            var storedCardUserKey = form["StoredCard"];
            if (!storedCardUserKey.Contains("Select") && storedCardUserKey.Count == 1 && storedCardUserKey.First().Length > 5)
            {
                return Task.FromResult<IList<string>>(warnings);
            }
            //validate
            var validator = new Nop.Plugin.Payments.OderoPay.PaymentInfoValidator.PaymentInfoValidator(_localizationService);
            var model = new PaymentInfoModel
            {
                CardholderName = form["CardholderName"],
                CardNumber = form["CardNumber"],
                CardCode = form["CardCode"],
                ExpireMonth = form["ExpireMonth"],
                ExpireYear = form["ExpireYear"],
                AllowStoreCard = form["AllowStoreCard"].Contains("true"),
                CreditCardType = form["Use3dSecure"].Contains("true") ? "3dSecurePayment" : "Non3dSecurePayment",
                CardAlias = form["CardAlias"]
            };
            var validationResult = validator.Validate(model);
            if (!validationResult.IsValid)
                warnings.AddRange(validationResult.Errors.Select(error => error.ErrorMessage));

            return Task.FromResult<IList<string>>(warnings);
        }

        public Task<ProcessPaymentRequest> GetPaymentInfoAsync(IFormCollection form)
        {
            var processPaymentRequest = new ProcessPaymentRequest();
            var storedCardUserKey = form["StoredCard"];
            if (!storedCardUserKey.Contains("Select") && storedCardUserKey.Count == 1 && storedCardUserKey.First().Length > 5)
            {
                processPaymentRequest.CustomValues.TryAdd("StoredCardUserKey",storedCardUserKey.First());
                return Task.FromResult(processPaymentRequest);
            }

            //Will be used for if payment initiated with 3ds or non-3ds
            processPaymentRequest.CreditCardType = form["Use3dSecure"].Contains("true") ? "3dSecurePayment" : "Non3dSecurePayment" ;
            
            processPaymentRequest.CreditCardCvv2 = form["CardCode"];
            processPaymentRequest.CreditCardExpireYear = int.Parse(form["ExpireYear"]);
            processPaymentRequest.CreditCardExpireMonth = int.Parse(form["ExpireMonth"]);
            processPaymentRequest.CreditCardNumber = form["CardNumber"];
            processPaymentRequest.CreditCardName = form["CardholderName"];

            var allowStoreCard = form["AllowStoreCard"].Contains("true");
            var cardAlias = form["CardAlias"];
            if (!allowStoreCard) return Task.FromResult(processPaymentRequest);


            processPaymentRequest.CustomValues.TryAdd("AllowStoreCard", true);
            processPaymentRequest.CustomValues.TryAdd("CardAlias", cardAlias.First());

            return Task.FromResult(processPaymentRequest);
        }

        public override string GetConfigurationPageUrl()
        {
            return $"{_webHelper.GetStoreLocation()}Admin/PaymentOderoPay/Configure";
        }

        public Type GetPublicViewComponent()
        {
            return typeof(PaymentOderoPayViewComponent);
        }

        public override async Task InstallAsync()
        {
            var settings = new OderoPayPaymentSettings
            {
                ApiKey = "",
                SecretKey = "",
                EndpointUrl = "",
                Use3DSecure = false,
                AdditionalFee = 0,
                AdditionalFeePercentage = false
            };
            await _settingService.SaveSettingAsync(settings);

            await _localizationService.AddOrUpdateLocaleResourceAsync(new Dictionary<string, string>
            {
                ["Plugins.Payments.OderoPay.Fields.ApiKey"] = "API Key",
                ["Plugins.Payments.OderoPay.Fields.SecretKey"] = "Secret Key",
                ["Plugins.Payments.OderoPay.Fields.EndpointUrl"] = "Endpoint URL",
                ["Plugins.Payments.OderoPay.Fields.Use3DSecure"] = "Use 3D Secure",
                ["Plugins.Payments.OderoPay.PaymentMethodDescription"] = "Pay by credit / debit card"
            });

            await base.InstallAsync();
        }

        public override async Task UninstallAsync()
        {
            await _settingService.DeleteSettingAsync<OderoPayPaymentSettings>();

            await _localizationService.DeleteLocaleResourcesAsync("Plugins.Payments.OderoPay");

            await base.UninstallAsync();
        }

        public async Task<string> GetPaymentMethodDescriptionAsync()
        {
            return await _localizationService.GetResourceAsync("Plugins.Payments.OderoPay.PaymentMethodDescription");
        }

        public bool SupportCapture => false;
        public bool SupportPartiallyRefund => false;
        public bool SupportRefund => true;
        public bool SupportVoid => false;
        public RecurringPaymentType RecurringPaymentType => RecurringPaymentType.NotSupported;
        public PaymentMethodType PaymentMethodType => PaymentMethodType.Redirection;
        public bool SkipPaymentInfo => false;



    }


}
