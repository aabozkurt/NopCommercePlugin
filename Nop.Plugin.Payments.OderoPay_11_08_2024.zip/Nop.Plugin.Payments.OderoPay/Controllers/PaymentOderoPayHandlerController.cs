﻿using Microsoft.AspNetCore.Mvc;
using Nop.Services.Orders;
using Nop.Core.Domain.Orders;
using Nop.Core.Events;
using TokenPay;
using TokenPay.Model;
using TokenPay.Request;

namespace Nop.Plugin.Payments.OderoPay.Controllers
{
    public class PaymentOderoPayHandlerController : Controller
    {
        private readonly IOrderService _orderService;
        private readonly OderoPayPaymentSettings _oderoPayPaymentSettings;
        private readonly IEventPublisher _eventPublisher;

        public PaymentOderoPayHandlerController(IOrderService orderService, OderoPayPaymentSettings oderoPayPaymentSettings, IEventPublisher eventPublisher)
        {
            _orderService = orderService;
            _oderoPayPaymentSettings = oderoPayPaymentSettings;
            _eventPublisher = eventPublisher;
        }

        [HttpPost]
        public async Task<IActionResult> Handler([FromForm] Secure3DHandler model)
        {
            if (ModelState.IsValid)
            {
                var order = _orderService.GetOrderByGuidAsync(new Guid(model.conversationId)).Result;
                if (order == null || model.paymentId == string.Empty)
                    return RedirectToAction("Index", "Home", new { area = "" });
                var client = new TokenPayClient(_oderoPayPaymentSettings.ApiKey, _oderoPayPaymentSettings.SecretKey, "https://sandbox-api-gateway.oderopay.com.tr");

                var check = client.Payment().Complete3DSPayment(new CompleteThreeDSPaymentRequest()
                    { PaymentId = Convert.ToInt64(model.paymentId) });

                if (check.PaymentStatus == PaymentStatus.Success)
                {
                    order.OrderStatus = OrderStatus.Processing;
                    order.PaymentStatus = Core.Domain.Payments.PaymentStatus.Paid;
                    order.AuthorizationTransactionId = model.paymentId;
                    order.AuthorizationTransactionResult = check.CardUserKey;

                    order.CaptureTransactionResult = "";
                    await _orderService.UpdateOrderAsync(order);


                    await _eventPublisher.PublishAsync(new OrderPlacedEvent(order));
                    return RedirectToRoute("CheckoutCompleted", new { orderId = order.Id });
                }

                order.OrderStatus = OrderStatus.Cancelled;
                order.PaymentStatus = Core.Domain.Payments.PaymentStatus.Voided;
                await _orderService.UpdateOrderAsync(order);
                //await _eventPublisher.PublishAsync(new OrderPlacedEvent(order));
            }

            return RedirectToAction("Index", "Home", new { area = "" });
        }
        [NonAction]
        private bool ProcessThePayment(Order order, Secure3DHandler model)
        {
            return false;
        }
    }
}
