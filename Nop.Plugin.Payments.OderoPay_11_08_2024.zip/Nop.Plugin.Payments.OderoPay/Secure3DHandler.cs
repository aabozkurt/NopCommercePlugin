﻿using System.ComponentModel.DataAnnotations;

namespace Nop.Plugin.Payments.OderoPay
{
    public class Secure3DHandler
    {
        [Required]
        public string status { get; set; }
        public string paymentId { get; set; }
        public string conversationId { get; set; }
       
    }
}
